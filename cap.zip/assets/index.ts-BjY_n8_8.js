import{g as q,b as K}from"./storage-CH7qmTRd.js";import{a as j}from"./messages-B5a0aXIP.js";import{n as z,b as Y,m as X}from"./tween-DHXOj6Lr.js";import{f as Z,a as J,F as Q}from"./fail-reason-DX6p87CR.js";import{H as ee,i as te,a as ne,f as oe,e as D,b as ie,d as se,r as re,u as ae,h as le,l as ce,g as de,s as pe,j as ue,k as fe,m as me,n as he,o as ge}from"./widgets-C5cbut4J.js";import"./settings-CYhEgPfU.js";const be=".nc-cursor-layer{position:absolute;top:0;left:0;width:0;height:0;overflow:visible;z-index:1;pointer-events:none}.nc-cursor{position:absolute;left:0;top:0;z-index:2;pointer-events:none;opacity:0;transition:opacity .35s ease;will-change:transform}.nc-cursor .cur-inner{position:relative;transition:transform .12s ease}.nc-cursor.pressing .cur-inner{transform:scale(.82)}.nc-cursor svg{position:relative;display:block;filter:drop-shadow(0 2px 4px rgba(16,16,20,.35))}.nc-ripple{position:absolute;z-index:1;pointer-events:none;width:44px;height:44px;margin:-22px 0 0 -22px;border-radius:50%;border:2px solid #6938ef;opacity:0;transform:scale(.3)}.nc-ripple.go{animation:nc-ripple .48s cubic-bezier(.22,1,.36,1) both}@keyframes nc-ripple{0%{opacity:.7;transform:scale(.25)}to{opacity:0;transform:scale(1.1)}}",ve=2500,xe=350,U={x:120,y:90},ye='<svg width="21" height="24" viewBox="0 0 21 24"><path d="M3 1 L3 19.5 L7.8 15.2 L10.7 22.4 L14.1 21 L11.2 13.9 L17.6 13.6 Z" fill="#ffffff" stroke="#16161a" stroke-width="1.4" stroke-linejoin="round"></path></svg>',we=2e3;function Ee(d){const h=t=>typeof t=="number"&&Number.isFinite(t)?Math.min(we,Math.max(0,t)):null,y=h(d.waitMs),m=h(d.travelMs),g=h(d.pressMs);return y===null||m===null||g===null?null:{waitMs:y,travelMs:m,pressMs:g}}function Ce(d,h={}){const y=h.fadeAfterMs??ve,m=h.fadeMs??xe,g=d.root.ownerDocument,t=g.defaultView??window;function n(e){const a=g.createElement("div");return a.className=e,a}const s=g.createElement("style");s.textContent=be;const p=n("nc-cursor-layer"),w=n("nc-ripple"),b=n("nc-cursor"),C=n("cur-inner");C.insertAdjacentHTML("beforeend",ye),b.appendChild(C),p.append(w,b),d.root.append(s,p);let r=!0,M=!1,S=1,u=null,x="off",T=0,k=0,E=Promise.resolve(),o=null;function i(){o!==null&&(t.clearTimeout(o),o=null)}function f(e,a){u={x:e,y:a},b.style.transform=`translate(${e}px,${a}px)`}function v(e){i(),x!=="on"&&(x==="off"&&(d.setShown("cursor",!0),u===null&&f(Math.min(t.innerWidth-6,e.x+U.x),Math.min(t.innerHeight-6,e.y+U.y))),d.raise(),x="on",b.style.opacity="1")}function L(){i(),b.style.opacity="0",b.classList.remove("pressing"),w.classList.remove("go"),x="off",d.setShown("cursor",!1)}function A(){x="fading",b.style.opacity="0",b.classList.remove("pressing"),o=t.setTimeout(L,m)}function P(){if(i(),x!=="off"){if(x==="fading"){A();return}o=t.setTimeout(A,y)}}async function N(e,a,c){const l=u??e;await Y(a,_=>{f(l.x+(e.x-l.x)*_,l.y+(e.y-l.y)*_)},c)}async function R(){u!==null&&(b.classList.add("pressing"),w.style.left=`${u.x}px`,w.style.top=`${u.y}px`,w.classList.remove("go"),w.offsetWidth,w.classList.add("go"),await z(130/S),b.classList.remove("pressing"))}async function G(e,a,c,l){switch(e){case"move":{if(c===void 0||l===void 0)return;v({x:c,y:l});const _=u??{x:c,y:l};await N({x:c,y:l},X(Math.hypot(c-_.x,l-_.y),S),a);return}case"press":if(x==="off"||u===null)return;v(u),b.classList.add("pressing");return;case"release":b.classList.remove("pressing");return;case"click":if(x==="off"||u===null)return;v(u),await R();return;default:return j(e)}}async function O(e,a){f(e.from.x,e.from.y),v(e.from),await z(e.waitMs),a()&&(await N(e.to,e.travelMs,a),a()&&(await z(e.pressMs),a()&&await R()))}function I(e){if(!r||M)return;const a=T,c=()=>a===T;k+=1,i(),E=E.then(()=>c()?e(c):void 0).catch(()=>{}).then(()=>{k-=1,k===0&&c()&&P()})}return{apply(e,a,c){I(l=>G(e,l,a,c))},glide(e){I(a=>O(e,a))},setEnabled(e){M||e===r||(r=e,!e&&(T+=1,L()))},setSpeed(e){S=e},settled(){return E},destroy(){M||(M=!0,T+=1,L(),s.remove(),p.remove())}}}const ke=":host{all:initial!important;display:block!important;position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;overflow:visible!important;z-index:2147483647!important;pointer-events:none!important}";function Le(d){const h=d.createElement("div"),y=h.attachShadow({mode:"closed"}),m=d.createElement("style");m.textContent=ke,y.appendChild(m);const g=new Set;let t=!1;function n(){return d.body??d.documentElement}function s(){n()?.appendChild(h)}return{root:y,setShown(p,w){t||(w?g.add(p):g.delete(p),g.size===0?h.remove():h.isConnected||s())},raise(){if(t||g.size===0)return;const p=n();p!==null&&(!h.isConnected||p.lastElementChild!==h)&&s()},destroy(){t=!0,g.clear(),h.remove()}}}const Se='.nc-pill-box{position:fixed;top:16px;right:16px;pointer-events:none}.nc-pill{display:flex;align-items:center;gap:9px;height:38px;padding:0 14px 0 10px;border-radius:19px;background:#131318;border:1px solid #2a2a31;color:#ebebe7;font-size:12px;font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;line-height:1.5;box-shadow:0 8px 28px -8px #1313188c,0 0 0 3px #7c4dff17;animation:pillin .32s cubic-bezier(.22,1,.36,1) both;white-space:nowrap;pointer-events:none}@keyframes pillin{0%{opacity:0;transform:translateY(8px) scale(.95)}to{opacity:1;transform:none}}.nc-pill.working{animation:glowpulse 1.6s ease-in-out infinite}@keyframes glowpulse{0%,to{box-shadow:0 8px 28px -8px #1313188c,0 0 0 3px #7c4dff1a}50%{box-shadow:0 8px 28px -8px #1313188c,0 0 0 6px #7c4dff38}}.nc-mark{width:16px;height:16px;border-radius:4px;background:linear-gradient(135deg,#7c4dff,#4e1ed1);position:relative;flex-shrink:0;box-shadow:0 0 0 1px #6938ef33}.nc-mark:after{content:"";position:absolute;left:18%;right:18%;top:18%;height:18%;border-radius:99px;background:#ffffffd9}.nc-mark:before{content:"";position:absolute;left:18%;right:18%;bottom:18%;height:18%;border-radius:99px;background:#ffffff73}.nc-pill .p-status{font-family:Geist Mono,ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;letter-spacing:.01em}.nc-pill .p-sub{color:#8e8e96;font-family:Geist Mono,ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px}.nc-pill .p-dot{width:6px;height:6px;border-radius:50%;background:#b39cff}.nc-pill .p-dot.pulse{animation:dotpulse 1.1s ease-in-out infinite}@keyframes dotpulse{0%,to{opacity:1}50%{opacity:.35}}.nc-pill .p-spin{width:12px;height:12px;border-radius:50%;border:2px solid #2a2a31;border-top-color:#b39cff;animation:capspin .7s linear infinite}@keyframes capspin{to{transform:rotate(360deg)}}.nc-pill .p-check{width:15px;height:15px;border-radius:50%;background:#1f9d6c;color:#fff;display:flex;align-items:center;justify-content:center;font-size:9px;animation:tickpop .3s cubic-bezier(.34,1.56,.64,1) both}@keyframes tickpop{0%{transform:scale(.2);opacity:0}to{transform:scale(1);opacity:1}}.nc-pill .p-ticks{display:inline-flex;gap:3px;margin-left:2px}.nc-pill .p-tick{width:4px;height:4px;border-radius:50%;background:#33333b;transition:background .25s ease}.nc-pill .p-tick.on{background:#b39cff}.nc-pill.warn{box-shadow:0 8px 28px -8px #1313188c,0 0 0 3px #a1731424}.nc-pill.warn .p-dot{background:#e2b53e}.nc-pill .p-cta{height:24px;padding:0 10px;margin-left:2px;border-radius:12px;border:none;background:#6938ef;color:#fff;font-size:11px;font-weight:600;font-family:inherit;cursor:pointer;pointer-events:auto}.nc-pill .p-cta:hover{background:#5b2ee0}.nc-pill .p-code{height:22px;padding:0 8px;margin-left:2px;border-radius:11px;border:1px solid #2a2a31;background:#1b1b21;color:#8e8e96;font-family:Geist Mono,ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10.5px;cursor:pointer;pointer-events:auto}.nc-pill .p-code:hover{color:#ebebe7;border-color:#3a3a44}',Te=38,$=10,H=8,Me={detected:"Captcha detected",opening:"Opening challenge",solving:"Solving",verifying:"Verifying"},B=["detected","opening","solving","verifying"];function _e(d,h={}){const y=d.root.ownerDocument,m=y.defaultView??window,g=y.createElement("style");g.textContent=Se;const t=y.createElement("div");t.className="nc-pill-box",t.style.display="none";const n=y.createElement("div");n.className="nc-pill",n.setAttribute("role","status"),t.appendChild(n),d.root.append(g,t);let s="idle",p,w=!0,b=null,C=!1;function r(o,i,f){const v=y.createElement(o);return v.className=i,f!==void 0&&(v.textContent=f),v}function M(){return t.offsetHeight||Te}function S(){if(t.style.display==="none")return;const o=b?.isConnected?b.getBoundingClientRect():null;if(!o||o.width*o.height===0){t.style.top="16px",t.style.right="16px";return}const i=M(),f=o.top-i-$,v=Math.min(o.bottom+$,m.innerHeight-i-H),L=f>=H?f:v;t.style.top=`${Math.max(H,L)}px`,t.style.right=`${Math.max(H,m.innerWidth-o.right)}px`}let u=null;function x(){if(u!==null||C)return;const o=()=>{u=null,C||S()};if(typeof m.requestAnimationFrame=="function"){const i=m.requestAnimationFrame(o);u=()=>m.cancelAnimationFrame(i)}else{const i=m.setTimeout(o,16);u=()=>m.clearTimeout(i)}}m.addEventListener("scroll",x,{capture:!0,passive:!0}),m.addEventListener("resize",x,{passive:!0});function T(o,i){const f=r("button","p-code",Z(o,i));return f.type="button",f.title="Copy this failure’s reference",f.addEventListener("click",()=>{navigator.clipboard?.writeText(J(o,i)).then(()=>{f.textContent="copied"},()=>{})}),f}function k(){return!C&&w&&s!=="idle"&&s!=="paused"}function E(){const o=k();if(t.style.display=o?"block":"none",d.setShown("pill",o),!!o){switch(n.classList.toggle("warn",s==="blocked"||s==="error"||s==="unregistered"||s==="throttled"),n.classList.toggle("working",s==="opening"||s==="solving"||s==="verifying"),n.replaceChildren(),n.appendChild(r("div","nc-mark")),s){case"blocked":case"unregistered":{if(n.appendChild(r("span","p-dot")),s==="blocked"&&p?.paused==="account"){n.appendChild(r("span","p-status","Solving paused for this account")),p.message&&n.appendChild(r("span","p-sub",p.message));break}n.appendChild(r("span","p-status",s==="blocked"?"Out of free solves":"NoneCap isn’t set up yet"));const i=r("button","p-cta","Add API key");i.type="button",i.addEventListener("click",()=>h.onCta?.()),n.appendChild(i);break}case"error":{n.appendChild(r("span","p-dot")),n.appendChild(r("span","p-status","Solve failed"));const i=p?.reason;i!==void 0&&(n.appendChild(r("span","p-sub",Q[i])),n.appendChild(T(i,p?.session)));break}case"throttled":n.appendChild(r("span","p-dot")),n.appendChild(r("span","p-status","hCaptcha rate-limited this IP"));break;case"solved":{n.appendChild(r("span","p-check","✓"));const i=p?.secs;n.appendChild(r("span","p-status",i!==void 0?`Solved in ${i}s`:"Solved"));const f=p?.credits;f!==void 0&&n.appendChild(r("span","p-sub",`−${f} credit${f===1?"":"s"}`));break}case"detected":case"opening":case"solving":case"verifying":{const i=s!=="detected";n.appendChild(r("span",i?"p-spin":"p-dot pulse")),n.appendChild(r("span","p-status",Me[s]));const f=B.indexOf(s),v=r("span","p-ticks");for(let L=0;L<B.length;L++)v.appendChild(r("span","p-tick"+(L<=f?" on":"")));n.appendChild(v);break}case"idle":case"paused":break;default:j(s)}S()}}return{setPhase(o,i){C||(s=o,p=i,E())},setAnchor(o){C||o===b||(b=o,x())},setVisible(o){C||o===w||(w=o,E())},state(){return{phase:s,text:k()?n.querySelector(".p-status")?.textContent??"":""}},destroy(){C||(C=!0,u?.(),u=null,m.removeEventListener("scroll",x,!0),m.removeEventListener("resize",x),d.setShown("pill",!1),g.remove(),t.remove())}}}const Ae=500,Oe=300,Ne=100;let F=null;function Ie(){try{return chrome.runtime?.id!==void 0}catch{return!1}}function V(d){try{chrome.runtime.sendMessage(d,()=>{chrome.runtime.lastError})}catch{F?.(),F=null}}function Fe(){const d=location.hostname;let h=!1,y=!1,m=!1,g=!0;const t=()=>y||m,n=Le(document),s=_e(n,{onCta:()=>{V({t:"OPEN_OPTIONS"})}}),p=Ce(n);function w(e){y=e.blocklist.includes(d),m=e.pausedHosts.includes(d),g=e.showOverlay,s.setVisible(g&&!t()),p.setEnabled(g&&!t()),p.setSpeed(e.style==="fast"?3:1),t()&&b()}function b(){M.reset(),x(!1)}q("settings").then(e=>{h||w(e)}).catch(()=>{});const C=K(e=>{e.settings&&w(e.settings)});let r=!1;const M=me();function S(e){const a=M.note(e);a!==null&&(x(a==="opened"),a==="closed"&&V({t:"ENCLAVE_CLOSED"}))}let u=null;function x(e){if(!e){u?.disconnect(),u=null;return}u===null&&(u=new MutationObserver(()=>S(D(document))),u.observe(document.documentElement,{attributes:!0,subtree:!0,attributeFilter:["style","class","hidden"]}))}function T(){if(!Ie()){O();return}/* [nc-patch] skip hidden check – allow solve in minimized window */if(t()){r=!1,b(),s.setAnchor(null);return}if(document.getElementsByTagName("iframe").length===0){r=!1,S(!1),s.setAnchor(null);return}const e=oe(document);r=e.checkbox!==null||e.challenge!==null||e.enclave!==null,S(D(document)),s.setAnchor(e.checkbox)}let k=null,E=!1;function o(e=!1){/* [nc-patch] skip hidden check */if(t()||!e&&(!r&&!E))return;let a=!1;for(const c of ie(document))if(c.value.trim().length>0){a=!0;break}a&&!E?i():!a&&E&&(E=!1)}function i(){E=!0;const e=k===null?0:Math.round((performance.now()-k)/100)/10;k=null,V({t:"SOLVED",secs:e}),window.__ncOnCaptchaSolved?.()}function f(e){r&&!E&&!t()&&he(e)&&i(),L()}let v=null;function L(){v===null&&(v=setTimeout(()=>{v=null,T(),o()},Ne))}const A=()=>o(!0);window.addEventListener("beforeunload",A),window.addEventListener("pagehide",A);const P=e=>{if(te(e.data)){try{window.__ncOnCaptchaSolved?.()}catch(_){}}e.origin!==ee||E||t()||te(e.data)&&ne(document,e.source)&&i()};window.addEventListener("message",P);const N=new MutationObserver(f);N.observe(document.documentElement,{childList:!0,subtree:!0});const R=setInterval(T,Ae),G=setInterval(o,Oe);function O(){if(!h){h=!0,clearInterval(R),clearInterval(G),v!==null&&clearTimeout(v),v=null,N.disconnect(),x(!1),window.removeEventListener("beforeunload",A),window.removeEventListener("pagehide",A),window.removeEventListener("message",P);try{C(),chrome.runtime.onMessage.removeListener(I)}catch{}s.destroy(),p.destroy(),n.destroy(),F===O&&(F=null)}}F=O;function I(e,a,c){const l=e;if(!(!l||typeof l!="object"))switch(l.t){case"GET_CHALLENGE_RECT":c(t()?null:fe(document));return;case"GET_ENCLAVE_RECT":c(t()?null:ue(document));return;case"SCROLL_CHALLENGE_INTO_VIEW":c(t()?{scrolled:!1}:pe(document,l.y));return;case"REVEAL_CHALLENGE":c(t()?{scrolled:!1}:de(document));return;case"LIFT_CHALLENGE":c(ce(document,l.dy));return;case"HIT_TEST":c(t()?null:le(document,l.x,l.y));return;case"UNCOVER_POINTS":c(t()?null:ae(document,l.points,n.root.host));return;case"RECOVER_POINTS":ge();return;case"GET_TOKEN_STATE":c(t()?null:re(document));return;case"PHASE":l.phase==="detected"&&(k=performance.now()),(l.phase==="solved"&&window.__ncOnCaptchaSolved?.()),s.setPhase(l.phase,l.detail);return;case"CURSOR_TOP":p.apply(l.op,l.x,l.y);return;case"CHECKBOX_CURSOR":{const _=se(document,l.cursor),W=Ee(l.cursor);_!==null&&W!==null&&p.glide({..._,...W});return}case"GET_PILL_STATE":c(s.state());return;default:return}}return chrome.runtime.onMessage.addListener(I),T(),o(),console.debug("[nonecap] page content script loaded"),O}window.__ncPage||(window.__ncPage=!0,Fe());
/* [nc-patch] Auto Join Rain & Post-Solve Join Rain */
(function __ncInitRain() {
  let isHandlingInitialRain = false;
  let isPostSolveActive = false;
  let postSolveTimer = null;
  let lastSolveTime = 0;

  function simulateClick(el) {
    if (!el) return;
    try {
      el.focus?.();
      ['mouseover', 'mouseenter', 'mousedown', 'mouseup', 'click'].forEach(eventType => {
        el.dispatchEvent(new MouseEvent(eventType, {
          bubbles: true,
          cancelable: true,
          view: window
        }));
      });
      el.click();
    } catch (_) {
      try { el.click(); } catch (__) {}
    }
  }

  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const rect = el.getBoundingClientRect();
    return !!(el.offsetWidth || el.offsetHeight || (rect.width > 0 && rect.height > 0));
  }

  function matchesBtn1(btn) {
    const text = (btn.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text.includes('Join Rain')) return false;
    const cls = btn.className || '';
    // Initial join button has px-7 / rounded-lg / bg-[#16A34A] and NOT full width
    return (cls.includes('px-7') || cls.includes('shadow-[0_0_16px_rgba(22,163,74,0.5)]') || cls.includes('hover:scale-[1.03]')) ||
           (!cls.includes('w-full') && cls.includes('bg-[#16A34A]'));
  }

  function matchesBtn2(btn) {
    const text = (btn.textContent || '').replace(/\s+/g, ' ').trim();
    if (!text.includes('Join Rain')) return false;
    const cls = btn.className || '';
    // Modal confirmation button has w-full / rounded-xl / uppercase / py-3
    return cls.includes('w-full') || cls.includes('rounded-xl') || cls.includes('uppercase') || (cls.includes('py-3') && cls.includes('bg-[#16A34A]'));
  }

  function findBtn1() {
    return Array.from(document.querySelectorAll('button')).find(btn => matchesBtn1(btn) && isVisible(btn) && !btn.disabled);
  }

  function findBtn2() {
    return Array.from(document.querySelectorAll('button')).find(btn => matchesBtn2(btn) && isVisible(btn) && !btn.disabled);
  }

  function checkInitialRain() {
    // If modal button 2 is already visible or post-solve is active, do not click initial button
    if (isHandlingInitialRain || isPostSolveActive || findBtn2()) return;

    const btn1 = findBtn1();
    if (btn1) {
      isHandlingInitialRain = true;
      console.log('[nonecap] Detected Join Rain initial button, clicking...', btn1);
      simulateClick(btn1);
      setTimeout(() => {
        isHandlingInitialRain = false;
      }, 2500);
    }
  }

  function executePostSolveClick() {
    const btn2 = findBtn2();
    if (btn2) {
      console.log('[nonecap] Found post-solve Join Rain button! Clicking...', btn2);
      simulateClick(btn2);
      // Double click confirmation
      setTimeout(() => {
        const stillActive = findBtn2();
        if (stillActive) {
          console.log('[nonecap] Confirmation click on post-solve Join Rain button...', stillActive);
          simulateClick(stillActive);
        }
      }, 250);
      return true;
    }
    return false;
  }

  window.__ncOnCaptchaSolved = function() {
    const now = Date.now();
    // Throttle duplicate solve events within 1.5s
    if (now - lastSolveTime < 1500 && isPostSolveActive) return;
    lastSolveTime = now;
    isPostSolveActive = true;

    console.log('[nonecap] Captcha solved signal received! Actively scanning for modal Join Rain button...');
    if (postSolveTimer) clearInterval(postSolveTimer);

    // Immediate attempt
    if (executePostSolveClick()) {
      setTimeout(() => { isPostSolveActive = false; }, 3000);
      return;
    }

    let attempts = 0;
    const maxAttempts = 75; // 75 * 200ms = 15 seconds
    postSolveTimer = setInterval(() => {
      attempts++;
      if (executePostSolveClick()) {
        clearInterval(postSolveTimer);
        postSolveTimer = null;
        setTimeout(() => { isPostSolveActive = false; }, 3000);
      } else if (attempts >= maxAttempts) {
        clearInterval(postSolveTimer);
        postSolveTimer = null;
        isPostSolveActive = false;
        console.log('[nonecap] Post-solve Join Rain button search finished after timeout.');
      }
    }, 200);
  };

  // Watch for response tokens in textareas (h-captcha-response / g-recaptcha-response)
  function checkResponseTokens() {
    const textareas = document.querySelectorAll('textarea[name="h-captcha-response"], textarea[name="g-recaptcha-response"]');
    for (const ta of textareas) {
      if (ta.value && ta.value.trim().length > 0) {
        if (!isPostSolveActive) {
          window.__ncOnCaptchaSolved();
        } else {
          executePostSolveClick();
        }
        break;
      }
    }
  }

  // Periodic heartbeat
  setInterval(() => {
    checkInitialRain();
    checkResponseTokens();
  }, 500);

  // Mutation observer
  const observer = new MutationObserver(() => {
    checkInitialRain();
    if (findBtn2()) {
      checkResponseTokens();
      if (isPostSolveActive) {
        executePostSolveClick();
      }
    }
  });

  const attachObserver = () => {
    if (document.body) {
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'style', 'disabled', 'hidden']
      });
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attachObserver);
  } else {
    attachObserver();
  }
})();


export{Fe as startPageScript};
